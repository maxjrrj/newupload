import styled from "styled-components";

export const Screen = styled.div`
  margin: 0;
  padding: 0;
  box-sizing: border-box;

  width: 100vw;
  height: 100vh;

  max-width: 100vw;
  max-height: 100vh;
`;
