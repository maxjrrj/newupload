import Header from "../../Components/Header/Header"
import Footer from "../../Components/Footer/Footer"
import BodyDetail from "../../Components/BodyDetail/BodyDetail"

const ProductDetailPage = () => {



return(
    <>
    <Header/>
    <BodyDetail/>
    <Footer/>
    </>
);
}

export default ProductDetailPage