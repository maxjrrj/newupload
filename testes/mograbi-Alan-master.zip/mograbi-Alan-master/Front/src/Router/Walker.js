export const goToPage = (history, path) => {
    history.push(path)
  };

  