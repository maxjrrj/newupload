import styled from "styled-components"


export const BoxTags = styled.div`
display:flex;
`

export const BoxTitleQty = styled.div`

`

export const Title = styled.div`
`

export const Qty = styled.div`

`