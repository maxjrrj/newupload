import styled from "styled-components"

export const ContainerTexto = styled.div`

height: 90vh;
`